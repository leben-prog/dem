using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using demov4.Models;

namespace demov4.Data
{
    /// <summary>
    /// Класс для работы с базой данных
    /// </summary>
    public class DatabaseHelper
    {
        private readonly string connectionString;

        public DatabaseHelper()
        {
            connectionString = @"Data Source=DESKTOP-FNEM53C;Initial Catalog=MosaicDB;Integrated Security=True;TrustServerCertificate=True";
        }

        /// <summary>
        /// Получение списка всех материалов
        /// </summary>
        public List<Material> GetAllMaterials(string materialNameFilter = null, int? materialTypeIdFilter = null, int? productTypeIdFilter = null)
        {
            var materials = new List<Material>();

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = @"SELECT m.MaterialID, m.MaterialName, m.MaterialTypeID, m.ProductTypeID,
                                           m.UnitPrice, m.StockQuantity, m.MinimumQuantity, m.PackageQuantity, m.UnitOfMeasure
                                    FROM Materials m
                                    WHERE (LEN(@MaterialNameFilter) = 0 OR m.MaterialName LIKE '%' + @MaterialNameFilter + '%')
                                      AND (@MaterialTypeIDFilter IS NULL OR @MaterialTypeIDFilter = -1 OR m.MaterialTypeID = @MaterialTypeIDFilter)
                                      AND (@ProductTypeIDFilter IS NULL OR @ProductTypeIDFilter = -1 OR m.ProductTypeID = @ProductTypeIDFilter)
                                    ORDER BY m.MaterialName";

                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@MaterialNameFilter", materialNameFilter ?? string.Empty);
                        command.Parameters.AddWithValue("@MaterialTypeIDFilter", materialTypeIdFilter ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@ProductTypeIDFilter", productTypeIdFilter ?? (object)DBNull.Value);

                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                materials.Add(new Material
                                {
                                    MaterialID = reader.GetInt32(0),
                                    MaterialName = reader.IsDBNull(1) ? string.Empty : reader.GetString(1),
                                    MaterialTypeID = reader.IsDBNull(2) ? 0 : reader.GetInt32(2),
                                    ProductTypeID = reader.IsDBNull(3) ? 0 : reader.GetInt32(3),
                                    UnitPrice = reader.IsDBNull(4) ? 0 : reader.GetDecimal(4),
                                    StockQuantity = reader.IsDBNull(5) ? 0 : reader.GetDecimal(5),
                                    MinimumQuantity = reader.IsDBNull(6) ? 0 : reader.GetDecimal(6),
                                    PackageQuantity = reader.IsDBNull(7) ? 0 : reader.GetInt32(7),
                                    UnitOfMeasure = reader.IsDBNull(8) ? string.Empty : reader.GetString(8)
                                });
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка при получении списка материалов: {ex.Message}");
            }

            return materials;
        }

        /// <summary>
        /// Получение материала по ID
        /// </summary>
        public Material GetMaterialById(int materialId)
        {
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = @"SELECT m.MaterialID, m.MaterialName, m.MaterialTypeID, m.ProductTypeID, m.UnitPrice, m.StockQuantity, m.MinimumQuantity, m.PackageQuantity, m.UnitOfMeasure 
                                   FROM Materials m 
                                   WHERE m.MaterialID = @MaterialID";

                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@MaterialID", materialId);
                        using (var reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                return new Material
                                {
                                    MaterialID = reader.GetInt32(0),
                                    MaterialName = reader.IsDBNull(1) ? string.Empty : reader.GetString(1),
                                    MaterialTypeID = reader.IsDBNull(2) ? 0 : reader.GetInt32(2),
                                    ProductTypeID = reader.GetInt32(3),
                                    UnitPrice = reader.IsDBNull(4) ? 0 : reader.GetDecimal(4),
                                    StockQuantity = reader.IsDBNull(5) ? 0 : reader.GetDecimal(5),
                                    MinimumQuantity = reader.IsDBNull(6) ? 0 : reader.GetDecimal(6),
                                    PackageQuantity = reader.IsDBNull(7) ? 0 : reader.GetInt32(7),
                                    UnitOfMeasure = reader.IsDBNull(8) ? string.Empty : reader.GetString(8)
                                };
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка при получении материала: {ex.Message}");
            }

            return null;
        }

        /// <summary>
        /// Получение списка типов продукции
        /// </summary>
        public List<ProductType> GetProductTypes()
        {
            var productTypes = new List<ProductType>();

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT ProductTypeId, ProductTypeName, Coefficient FROM ProductTypes ORDER BY ProductTypeName";

                    using (var command = new SqlCommand(query, connection))
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            productTypes.Add(new ProductType
                            {
                                ProductTypeId = reader.GetInt32(0),
                                ProductTypeName = reader.IsDBNull(1) ? string.Empty : reader.GetString(1),
                                Coefficient = reader.IsDBNull(2) ? 0 : reader.GetDecimal(2)
                            });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка при получении типов продукции: {ex.Message}");
            }

            return productTypes;
        }

        /// <summary>
        /// Добавление нового материала
        /// </summary>
        public void AddMaterial(Material material)
        {
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = @"INSERT INTO Materials (MaterialName, MaterialTypeID, ProductTypeID, UnitPrice, StockQuantity, MinimumQuantity, PackageQuantity, UnitOfMeasure) 
                                   VALUES (@MaterialName, @MaterialTypeID, @ProductTypeID, @UnitPrice, @StockQuantity, @MinimumQuantity, @PackageQuantity, @UnitOfMeasure)";

                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@MaterialName", material.MaterialName);
                        command.Parameters.AddWithValue("@MaterialTypeID", material.MaterialTypeID);
                        command.Parameters.AddWithValue("@ProductTypeID", material.ProductTypeID);
                        command.Parameters.AddWithValue("@UnitPrice", material.UnitPrice);
                        command.Parameters.AddWithValue("@StockQuantity", material.StockQuantity);
                        command.Parameters.AddWithValue("@MinimumQuantity", material.MinimumQuantity);
                        command.Parameters.AddWithValue("@PackageQuantity", material.PackageQuantity);
                        command.Parameters.AddWithValue("@UnitOfMeasure", material.UnitOfMeasure);

                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка при добавлении материала: {ex.Message}");
            }
        }

        /// <summary>
        /// Обновление материала
        /// </summary>
        public void UpdateMaterial(Material material)
        {
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = @"UPDATE Materials 
                                   SET MaterialName = @MaterialName, MaterialTypeID = @MaterialTypeID, 
                                       ProductTypeID = @ProductTypeID, UnitPrice = @UnitPrice, 
                                       StockQuantity = @StockQuantity, MinimumQuantity = @MinimumQuantity, 
                                       PackageQuantity = @PackageQuantity, UnitOfMeasure = @UnitOfMeasure 
                                   WHERE MaterialID = @MaterialID";

                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@MaterialID", material.MaterialID);
                        command.Parameters.AddWithValue("@MaterialName", material.MaterialName);
                        command.Parameters.AddWithValue("@MaterialTypeID", material.MaterialTypeID);
                        command.Parameters.AddWithValue("@ProductTypeID", material.ProductTypeID);
                        command.Parameters.AddWithValue("@UnitPrice", material.UnitPrice);
                        command.Parameters.AddWithValue("@StockQuantity", material.StockQuantity);
                        command.Parameters.AddWithValue("@MinimumQuantity", material.MinimumQuantity);
                        command.Parameters.AddWithValue("@PackageQuantity", material.PackageQuantity);
                        command.Parameters.AddWithValue("@UnitOfMeasure", material.UnitOfMeasure);

                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка при обновлении материала: {ex.Message}");
            }
        }

        /// <summary>
        /// Получение списка типов материала
        /// </summary>
        public List<MaterialType> GetMaterialTypes()
        {
            var materialTypes = new List<MaterialType>();

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT MaterialTypeID, MaterialTypeName, RawMaterialLossPercent FROM MaterialTypes ORDER BY MaterialTypeName";

                    using (var command = new SqlCommand(query, connection))
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            materialTypes.Add(new MaterialType
                            {
                                MaterialTypeID = reader.GetInt32(0),
                                MaterialTypeName = reader.IsDBNull(1) ? string.Empty : reader.GetString(1),
                                RawMaterialLossPercent = reader.IsDBNull(2) ? 0 : reader.GetDecimal(2)
                            });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка при получении типов материала: {ex.Message}");
            }

            return materialTypes;
        }

        /// <summary>
        /// Получение списка всех поставщиков
        /// </summary>
        public List<Supplier> GetAllSuppliers()
        {
            var suppliers = new List<Supplier>();

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT SupplierID, SupplierName, SupplierType, INN, Rating, StartDate FROM Suppliers ORDER BY SupplierName";

                    using (var command = new SqlCommand(query, connection))
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            suppliers.Add(new Supplier
                            {
                                SupplierID = reader.GetInt32(0),
                                SupplierName = reader.IsDBNull(1) ? string.Empty : reader.GetString(1),
                                SupplierType = reader.IsDBNull(2) ? string.Empty : reader.GetString(2),
                                INN = reader.IsDBNull(3) ? string.Empty : reader.GetString(3),
                                Rating = reader.IsDBNull(4) ? 0 : reader.GetInt32(4),
                                StartDate = reader.IsDBNull(5) ? DateTime.MinValue : reader.GetDateTime(5)
                            });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка при получении списка поставщиков: {ex.Message}");
            }

            return suppliers;
        }

        /// <summary>
        /// Получение поставщика по ID
        /// </summary>
        public Supplier GetSupplierById(int supplierId)
        {
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT SupplierID, SupplierName, SupplierType, INN, Rating, StartDate FROM Suppliers WHERE SupplierID = @SupplierID";

                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@SupplierID", supplierId);
                        using (var reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                return new Supplier
                                {
                                    SupplierID = reader.GetInt32(0),
                                    SupplierName = reader.IsDBNull(1) ? string.Empty : reader.GetString(1),
                                    SupplierType = reader.IsDBNull(2) ? string.Empty : reader.GetString(2),
                                    INN = reader.IsDBNull(3) ? string.Empty : reader.GetString(3),
                                    Rating = reader.IsDBNull(4) ? 0 : reader.GetInt32(4),
                                    StartDate = reader.IsDBNull(5) ? DateTime.MinValue : reader.GetDateTime(5)
                                };
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка при получении поставщика: {ex.Message}");
            }

            return null;
        }

        /// <summary>
        /// Добавление нового поставщика
        /// </summary>
        public void AddSupplier(Supplier supplier)
        {
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = @"INSERT INTO Suppliers (SupplierName, SupplierType, INN, Rating, StartDate) 
                                   VALUES (@SupplierName, @SupplierType, @INN, @Rating, @StartDate)";

                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@SupplierName", supplier.SupplierName);
                        command.Parameters.AddWithValue("@SupplierType", supplier.SupplierType);
                        command.Parameters.AddWithValue("@INN", supplier.INN);
                        command.Parameters.AddWithValue("@Rating", supplier.Rating);
                        command.Parameters.AddWithValue("@StartDate", supplier.StartDate);

                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка при добавлении поставщика: {ex.Message}");
            }
        }

        /// <summary>
        /// Обновление поставщика
        /// </summary>
        public void UpdateSupplier(Supplier supplier)
        {
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = @"UPDATE Suppliers 
                                   SET SupplierName = @SupplierName, SupplierType = @SupplierType, 
                                       INN = @INN, Rating = @Rating, StartDate = @StartDate 
                                   WHERE SupplierID = @SupplierID";

                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@SupplierID", supplier.SupplierID);
                        command.Parameters.AddWithValue("@SupplierName", supplier.SupplierName);
                        command.Parameters.AddWithValue("@SupplierType", supplier.SupplierType);
                        command.Parameters.AddWithValue("@INN", supplier.INN);
                        command.Parameters.AddWithValue("@Rating", supplier.Rating);
                        command.Parameters.AddWithValue("@StartDate", supplier.StartDate);

                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка при обновлении поставщика: {ex.Message}");
            }
        }

        /// <summary>
        /// Получение списка связей материалов и поставщиков
        /// </summary>
        public List<MaterialSupplier> GetAllMaterialSuppliers()
        {
            var materialSuppliers = new List<MaterialSupplier>();

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT MaterialSupplierID, MaterialID, SupplierID FROM MaterialSuppliers";

                    using (var command = new SqlCommand(query, connection))
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            materialSuppliers.Add(new MaterialSupplier
                            {
                                MaterialSupplierID = reader.GetInt32(0),
                                MaterialID = reader.GetInt32(1),
                                SupplierID = reader.GetInt32(2)
                            });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка при получении списка связей материалов и поставщиков: {ex.Message}");
            }

            return materialSuppliers;
        }

        /// <summary>
        /// Добавление новой связи материала и поставщика
        /// </summary>
        public void AddMaterialSupplier(MaterialSupplier materialSupplier)
        {
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = @"INSERT INTO MaterialSuppliers (MaterialID, SupplierID) 
                                   VALUES (@MaterialID, @SupplierID)";

                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@MaterialID", materialSupplier.MaterialID);
                        command.Parameters.AddWithValue("@SupplierID", materialSupplier.SupplierID);

                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка при добавлении связи материала и поставщика: {ex.Message}");
            }
        }

        /// <summary>
        /// Удаление связи материала и поставщика
        /// </summary>
        public void DeleteMaterialSupplier(int materialSupplierId)
        {
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "DELETE FROM MaterialSuppliers WHERE MaterialSupplierID = @MaterialSupplierID";

                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@MaterialSupplierID", materialSupplierId);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка при удалении связи материала и поставщика: {ex.Message}");
            }
        }

        /// <summary>
        /// Проверка подключения к базе данных
        /// </summary>
        public bool TestConnection()
        {
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    return true;
                }
            }
            catch
            {
                return false;
            }
        }

        public void DeleteMaterial(int materialId)
        {
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "DELETE FROM Materials WHERE MaterialID = @MaterialID";

                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@MaterialID", materialId);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка при удалении материала: {ex.Message}");
            }
        }

        public List<MaterialSupplier> GetAllMaterialSuppliersByMaterialId(int materialId)
        {
            var materialSuppliers = new List<MaterialSupplier>();

            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = @"SELECT ms.MaterialSupplierID, ms.MaterialID, ms.SupplierID,
                                           s.SupplierName, s.Rating
                                   FROM MaterialSuppliers ms
                                   JOIN Suppliers s ON ms.SupplierID = s.SupplierID
                                   WHERE ms.MaterialID = @MaterialID";

                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@MaterialID", materialId);
                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                materialSuppliers.Add(new MaterialSupplier
                                {
                                    MaterialSupplierID = reader.GetInt32(0),
                                    MaterialID = reader.GetInt32(1),
                                    SupplierID = reader.GetInt32(2),
                                    Supplier = new Supplier // Заполняем объект Supplier
                                    {
                                        SupplierID = reader.GetInt32(2), // ID поставщика
                                        SupplierName = reader.IsDBNull(3) ? string.Empty : reader.GetString(3), // Индекс изменился на 3
                                        Rating = reader.IsDBNull(4) ? 0 : reader.GetInt32(4) // Индекс изменился на 4
                                    }
                                });
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка при получении поставщиков материала: {ex.Message}");
            }

            return materialSuppliers;
        }

        /// <summary>
        /// Получение типа продукции по ID
        /// </summary>
        public ProductType GetProductTypeById(int productTypeId)
        {
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT ProductTypeId, ProductTypeName, Coefficient FROM ProductTypes WHERE ProductTypeId = @ProductTypeId";

                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@ProductTypeId", productTypeId);
                        using (var reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                return new ProductType
                                {
                                    ProductTypeId = reader.GetInt32(0),
                                    ProductTypeName = reader.IsDBNull(1) ? string.Empty : reader.GetString(1),
                                    Coefficient = reader.IsDBNull(2) ? 0 : reader.GetDecimal(2)
                                };
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка при получении типа продукции: {ex.Message}");
            }
            return null;
        }

        /// <summary>
        /// Получение типа материала по ID
        /// </summary>
        public MaterialType GetMaterialTypeById(int materialTypeId)
        {
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT MaterialTypeID, MaterialTypeName, RawMaterialLossPercent FROM MaterialTypes WHERE MaterialTypeID = @MaterialTypeID";

                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@MaterialTypeID", materialTypeId);
                        using (var reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                return new MaterialType
                                {
                                    MaterialTypeID = reader.GetInt32(0),
                                    MaterialTypeName = reader.IsDBNull(1) ? string.Empty : reader.GetString(1),
                                    RawMaterialLossPercent = reader.IsDBNull(2) ? 0 : reader.GetDecimal(2)
                                };
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка при получении типа материала: {ex.Message}");
            }
            return null;
        }
    }
} 