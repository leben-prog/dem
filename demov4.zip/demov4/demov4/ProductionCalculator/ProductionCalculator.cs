using System;
using demov4.Data;
using demov4.Models;

namespace demov4.ProductionCalculator
{
    public static class ProductionCalculator
    {
        /// <summary>
        /// Рассчитывает целое количество продукции, получаемой при использовании указанного количества сырья,
        /// с учетом возможных потерь сырья при производстве.
        /// </summary>
        /// <param name="productTypeId">Идентификатор типа продукции.</param>
        /// <param name="materialTypeId">Идентификатор типа материала.</param>
        /// <param name="rawMaterialQuantity">Количество используемого сырья (целое число).</param>
        /// <param name="productParameter1">Первый параметр продукции (вещественное, положительное число).</param>
        /// <param name="productParameter2">Второй параметр продукции (вещественное, положительное число).</param>
        /// <returns>Количество получаемой продукции (целое число), или -1 в случае некорректных данных.</returns>
        public static int CalculateProductQuantity(
            int productTypeId,
            int materialTypeId,
            int rawMaterialQuantity,
            decimal productParameter1,
            decimal productParameter2)
        {
            if (rawMaterialQuantity < 0 || productParameter1 <= 0 || productParameter2 <= 0)
            {
                return -1; // Недопустимые входные данные
            }

            try
            {
                var db = new DatabaseHelper();

                // Получаем тип продукции
                var productType = db.GetProductTypeById(productTypeId);
                if (productType == null) return -1; // Несуществующий тип продукции

                // Получаем тип материала
                var materialType = db.GetMaterialTypeById(materialTypeId);
                if (materialType == null) return -1; // Несуществующий тип материала

                // Количество сырья необходимого на одну единицу продукции (без учета потерь)
                // Рассчитывается как произведение параметров продукции, умноженное на коэффициент типа продукции.
                decimal rawMaterialPerProductUnit = productParameter1 * productParameter2 * productType.Coefficient;

                if (rawMaterialPerProductUnit <= 0)
                {
                    return -1; // Некорректное рассчитанное количество сырья на единицу продукции
                }

                // Учитываем процент потери сырья: необходимое количество сырья должно быть увеличено с учетом возможных потерь.
                // materialType.RawMaterialLossPercent - это процент, поэтому делим на 100
                decimal lossFactor = 1 + (materialType.RawMaterialLossPercent / 100M);
                decimal rawMaterialPerProductUnitWithLoss = rawMaterialPerProductUnit * lossFactor;

                if (rawMaterialPerProductUnitWithLoss <= 0)
                {
                    return -1; // Некорректное рассчитанное количество сырья на единицу продукции с учетом потерь
                }

                // Рассчитываем целое количество продукции
                int productQuantity = (int)Math.Floor(rawMaterialQuantity / rawMaterialPerProductUnitWithLoss);

                return productQuantity;
            }
            catch (Exception)
            {
                return -1; // Общая ошибка выполнения
            }
        }
    }
} 