using System;
using System.Data.SqlClient;

namespace demov4.Utils
{
    /// <summary>
    /// Класс для расчета количества сырья для производства продукции
    /// </summary>
    public static class RawMaterialCalculator
    {
        private static readonly string connectionString = @"Data Source=Uz1ps\SQLEXPRESS;Initial Catalog=FurnitureCompany;Integrated Security=True;TrustServerCertificate=True";

        /// <summary>
        /// Расчет количества сырья для производства продукции
        /// </summary>
        /// <param name="productTypeId">Идентификатор типа продукции</param>
        /// <param name="materialTypeId">Идентификатор типа материала</param>
        /// <param name="productQuantity">Количество продукции</param>
        /// <param name="parameter1">Первый параметр продукции</param>
        /// <param name="parameter2">Второй параметр продукции</param>
        /// <returns>Количество сырья с учетом потерь или -1 при ошибке</returns>
        public static int CalculateRawMaterialQuantity(int productTypeId, int materialTypeId, int productQuantity, decimal parameter1, decimal parameter2)
        {
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    
                    using (var command = new SqlCommand("CalculateRawMaterialQuantity", connection))
                    {
                        command.CommandType = System.Data.CommandType.StoredProcedure;
                        
                        // Входные параметры
                        command.Parameters.AddWithValue("@ProductTypeId", productTypeId);
                        command.Parameters.AddWithValue("@MaterialTypeId", materialTypeId);
                        command.Parameters.AddWithValue("@ProductQuantity", productQuantity);
                        command.Parameters.AddWithValue("@Parameter1", parameter1);
                        command.Parameters.AddWithValue("@Parameter2", parameter2);
                        
                        // Выходной параметр
                        var resultParameter = new SqlParameter("@Result", System.Data.SqlDbType.Int)
                        {
                            Direction = System.Data.ParameterDirection.Output
                        };
                        command.Parameters.Add(resultParameter);
                        
                        command.ExecuteNonQuery();
                        
                        return (int)resultParameter.Value;
                    }
                }
            }
            catch (Exception)
            {
                // При любой ошибке возвращаем -1
                return -1;
            }
        }

        /// <summary>
        /// Проверка корректности входных параметров
        /// </summary>
        /// <param name="productTypeId">Идентификатор типа продукции</param>
        /// <param name="materialTypeId">Идентификатор типа материала</param>
        /// <param name="productQuantity">Количество продукции</param>
        /// <param name="parameter1">Первый параметр продукции</param>
        /// <param name="parameter2">Второй параметр продукции</param>
        /// <returns>True если параметры корректны</returns>
        public static bool ValidateParameters(int productTypeId, int materialTypeId, int productQuantity, decimal parameter1, decimal parameter2)
        {
            return productTypeId > 0 && 
                   materialTypeId > 0 && 
                   productQuantity > 0 && 
                   parameter1 > 0 && 
                   parameter2 > 0;
        }
    }
} 