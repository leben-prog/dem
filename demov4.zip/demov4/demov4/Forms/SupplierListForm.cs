using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using demov4.Data;
using demov4.Models;

namespace demov4.Forms
{
    public partial class SupplierListForm : Form
    {
        private readonly DatabaseHelper _db;
        private readonly Material _material;
        private DataGridView dataGridViewSuppliers;
        private Label _labelTitle;

        public SupplierListForm(Material material)
        {
            _material = material;
            InitializeComponent();
            _db = new DatabaseHelper();
            InitializeCustomComponents();
            LoadSuppliers();
        }

        private void InitializeComponent()
        {
            this.Size = new Size(800, 500);
            this.MinimumSize = new Size(300, 300);
            this.StartPosition = FormStartPosition.CenterParent;
            this.BackColor = Color.White;
            this.Font = new Font("Comic Sans MS", 10F);

            // Заголовок формы (только создание объекта, текст устанавливаем позже)
            var labelTitle = new Label
            {
                Font = new Font("Comic Sans MS", 14F, FontStyle.Bold),
                Location = new Point(20, 20),
                Size = new Size(740, 30),
                ForeColor = ColorTranslator.FromHtml("#546F94")
            };

            // DataGridView для отображения поставщиков
            dataGridViewSuppliers = new DataGridView
            {
                Location = new Point(20, 60),
                Size = new Size(740, 380),
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                Font = new Font("Comic Sans MS", 9F)
            };

            // Настройка стиля DataGridView
            dataGridViewSuppliers.EnableHeadersVisualStyles = false;
            dataGridViewSuppliers.ColumnHeadersDefaultCellStyle.BackColor = ColorTranslator.FromHtml("#ABCFCE");
            dataGridViewSuppliers.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
            dataGridViewSuppliers.ColumnHeadersDefaultCellStyle.Font = new Font("Comic Sans MS", 10F, FontStyle.Bold);
            dataGridViewSuppliers.ColumnHeadersHeight = 35;

            dataGridViewSuppliers.DefaultCellStyle.SelectionBackColor = ColorTranslator.FromHtml("#546F94");
            dataGridViewSuppliers.DefaultCellStyle.SelectionForeColor = Color.White;
            dataGridViewSuppliers.AlternatingRowsDefaultCellStyle.BackColor = ColorTranslator.FromHtml("#F8F9FF");

            // Добавление компонентов на форму
            this.Controls.Add(labelTitle);
            this.Controls.Add(dataGridViewSuppliers);

            // Сохраняем ссылку на labelTitle, чтобы установить его текст позже
            this._labelTitle = labelTitle;
        }

        private void InitializeCustomComponents()
        {
            // Устанавливаем текст заголовка формы
            this.Text = $"Поставщики материала: {_material.MaterialName}";
            // Устанавливаем текст labelTitle
            _labelTitle.Text = $"Поставщики для \"{_material.MaterialName}\" - Рейтинг: {_material.ProductTypeID}";
        }

        private void LoadSuppliers()
        {
            try
            {
                var suppliers = _db.GetAllMaterialSuppliersByMaterialId(_material.MaterialID);

                dataGridViewSuppliers.DataSource = null;
                dataGridViewSuppliers.Columns.Clear();

                dataGridViewSuppliers.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name = "SupplierName",
                    HeaderText = "Наименование поставщика",
                    DataPropertyName = "SupplierName"
                });

                dataGridViewSuppliers.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name = "Rating",
                    HeaderText = "Рейтинг",
                    DataPropertyName = "Rating"
                });

                // Создание списка анонимных объектов для DataGridView
                var displaySuppliers = suppliers.Select(ms => new
                {
                    SupplierName = ms.Supplier?.SupplierName, // Использование безопасной навигации
                    Rating = ms.Supplier?.Rating
                }).ToList();

                dataGridViewSuppliers.DataSource = displaySuppliers;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке поставщиков: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
} 