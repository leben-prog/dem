using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using demov4.Data;
using demov4.Models;
using demov4.Forms;

namespace demov4.Forms
{
    /// <summary>
    /// Главная форма приложения для отображения списка материалов
    /// </summary>
    public partial class MainForm : Form
    {
        private DatabaseHelper databaseHelper;
        private List<Material> materials;
        private DataGridView dataGridViewMaterials;
        private Button buttonAdd;
        private Button buttonViewSuppliers;
        private PictureBox pictureBoxLogo;
        private TextBox txtSearchMaterialName;
        private ComboBox cmbMaterialTypeFilter;
        private ComboBox cmbProductTypeFilter;

        public MainForm()
        {
            InitializeComponent();
            databaseHelper = new DatabaseHelper();
            InitializeCustomComponents();
            LoadMaterials(); // Загрузка материалов вместо продуктов
        }

        /// <summary>
        /// Инициализация пользовательских компонентов
        /// </summary>
        private void InitializeCustomComponents()
        {
            // Настройка формы
            this.Text = "Система управления материалами - Комфорт";
            this.Size = new Size(900, 520); // Возвращаем более крупный размер по умолчанию
            this.MinimumSize = new Size(300, 300); // Установка минимального размера
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.White;
            this.Font = new Font("Comic Sans MS", 10F); // Изменение шрифта

            // Логотип компании (заглушка)
            pictureBoxLogo = new PictureBox
            {
                Size = new Size(100, 100),
                Location = new Point(20, 20),
                SizeMode = PictureBoxSizeMode.Zoom,
                BackColor = ColorTranslator.FromHtml("#ABCFCE"), // Изменение цвета фона логотипа
                BorderStyle = BorderStyle.FixedSingle
            };

            // Заголовок
            var labelTitle = new Label
            {
                Text = "Список материалов",
                Font = new Font("Comic Sans MS", 16F, FontStyle.Bold), // Изменение шрифта
                Location = new Point(140, 40),
                Size = new Size(300, 30),
                ForeColor = ColorTranslator.FromHtml("#546F94") // Изменение цвета заголовка
            };

            // Элементы управления для фильтрации
            var lblSearch = new Label { Text = "Поиск по наименованию: ", Location = new Point(20, 150), Font = new Font("Comic Sans MS", 10F) };
            txtSearchMaterialName = new TextBox { Location = new Point(20, 170), Width = 250, Font = new Font("Comic Sans MS", 10F) };
            txtSearchMaterialName.TextChanged += (s, e) => LoadMaterials(); // Загружаем материалы при изменении текста

            var lblMaterialTypeFilter = new Label { Text = "Тип материала: ", Location = new Point(280, 150), Font = new Font("Comic Sans MS", 10F) };
            cmbMaterialTypeFilter = new ComboBox { Location = new Point(280, 170), Width = 200, DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Comic Sans MS", 10F), BackColor = ColorTranslator.FromHtml("#ABCFCE") };
            cmbMaterialTypeFilter.SelectedIndexChanged += (s, e) => LoadMaterials(); // Загружаем материалы при изменении выбора

            var lblProductTypeFilter = new Label { Text = "Тип продукции: ", Location = new Point(500, 150), Font = new Font("Comic Sans MS", 10F) };
            cmbProductTypeFilter = new ComboBox { Location = new Point(500, 170), Width = 200, DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Comic Sans MS", 10F), BackColor = ColorTranslator.FromHtml("#ABCFCE") };
            cmbProductTypeFilter.SelectedIndexChanged += (s, e) => LoadMaterials(); // Загружаем материалы при изменении выбора

            // Кнопка добавления
            buttonAdd = new Button
            {
                Text = "Добавить материал",
                Font = new Font("Comic Sans MS", 10F),
                Size = new Size(150, 35),
                Location = new Point(20, 210), // Изменяем положение кнопок ниже фильтров
                BackColor = ColorTranslator.FromHtml("#546F94"),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            buttonAdd.FlatAppearance.BorderSize = 0;
            buttonAdd.Click += ButtonAdd_Click;

            // Кнопка удаления
            var buttonDelete = new Button
            {
                Text = "Удалить материал",
                Font = new Font("Comic Sans MS", 10F),
                Size = new Size(150, 35),
                Location = new Point(180, 210), // Смещаем правую кнопку
                BackColor = ColorTranslator.FromHtml("#546F94"),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            buttonDelete.FlatAppearance.BorderSize = 0;
            buttonDelete.Click += ButtonDelete_Click;

            // Кнопка просмотра поставщиков
            buttonViewSuppliers = new Button
            {
                Text = "Просмотр поставщиков",
                Font = new Font("Comic Sans MS", 10F),
                Size = new Size(180, 35),
                Location = new Point(350, 210), // Позиционируем справа от кнопки удаления
                BackColor = ColorTranslator.FromHtml("#546F94"),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand,
                Enabled = false
            };
            buttonViewSuppliers.FlatAppearance.BorderSize = 0;
            buttonViewSuppliers.Click += ButtonViewSuppliers_Click;

            // DataGridView для отображения материалов
            dataGridViewMaterials = new DataGridView
            {
                Location = new Point(20, 255), // Перемещаем ниже кнопок
                Size = new Size(this.ClientSize.Width - 40, this.ClientSize.Height - 245), // Автоматическое изменение размера
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None, // Изменение режима автоматического изменения размера столбцов
                Font = new Font("Comic Sans MS", 9F),
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right // Закрепляем по всем сторонам
            };

            // Настройка стиля DataGridView
            dataGridViewMaterials.EnableHeadersVisualStyles = false;
            dataGridViewMaterials.ColumnHeadersDefaultCellStyle.BackColor = ColorTranslator.FromHtml("#ABCFCE");
            dataGridViewMaterials.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
            dataGridViewMaterials.ColumnHeadersDefaultCellStyle.Font = new Font("Comic Sans MS", 10F, FontStyle.Bold);
            dataGridViewMaterials.ColumnHeadersHeight = 35;

            dataGridViewMaterials.DefaultCellStyle.SelectionBackColor = ColorTranslator.FromHtml("#546F94");
            dataGridViewMaterials.DefaultCellStyle.SelectionForeColor = Color.White;
            dataGridViewMaterials.AlternatingRowsDefaultCellStyle.BackColor = ColorTranslator.FromHtml("#F8F9FF");

            dataGridViewMaterials.CellDoubleClick += DataGridViewMaterials_CellDoubleClick;
            dataGridViewMaterials.SelectionChanged += DataGridViewMaterials_SelectionChanged;

            // Добавление компонентов на форму
            this.Controls.Add(pictureBoxLogo);
            this.Controls.Add(labelTitle);
            this.Controls.AddRange(new Control[] {
                lblSearch, txtSearchMaterialName,
                lblMaterialTypeFilter, cmbMaterialTypeFilter,
                lblProductTypeFilter, cmbProductTypeFilter
            }); // Добавляем элементы фильтрации
            this.Controls.Add(buttonAdd);
            this.Controls.Add(buttonDelete);
            this.Controls.Add(buttonViewSuppliers);
            this.Controls.Add(dataGridViewMaterials);

            // Загрузка фильтров после инициализации компонентов
            LoadMaterialTypeFilters();
            LoadProductTypeFilters();
        }

        /// <summary>
        /// Загрузка списка материалов из базы данных
        /// </summary>
        private void LoadMaterials()
        {
            try
            {
                // Проверка подключения к базе данных
                if (!databaseHelper.TestConnection())
                {
                    MessageBox.Show("Не удается подключиться к базе данных. Проверьте настройки подключения.",
                                  "Ошибка подключения", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Получаем значения фильтров
                string materialNameFilter = txtSearchMaterialName.Text.Trim();
                int? materialTypeIdFilter = cmbMaterialTypeFilter.SelectedValue as int?;
                int? productTypeIdFilter = cmbProductTypeFilter.SelectedValue as int?;

                // Обновляем метод GetAllMaterials для принятия параметров фильтрации
                materials = databaseHelper.GetAllMaterials(materialNameFilter, materialTypeIdFilter, productTypeIdFilter); // Вызываем с фильтрами

                // Настройка колонок DataGridView
                dataGridViewMaterials.DataSource = null;
                dataGridViewMaterials.Columns.Clear();

                dataGridViewMaterials.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name = "MaterialID",
                    HeaderText = "ID Мат.",
                    DataPropertyName = "MaterialID",
                    Width = 70
                });

                dataGridViewMaterials.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name = "MaterialName",
                    HeaderText = "Наименование",
                    DataPropertyName = "MaterialName",
                    Width = 170 // Измененная ширина
                });

                dataGridViewMaterials.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name = "MaterialTypeID",
                    HeaderText = "ID Типа Мат.",
                    DataPropertyName = "MaterialTypeID",
                    Width = 95 // Измененная ширина
                });

                dataGridViewMaterials.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name = "ProductTypeID",
                    HeaderText = "ID Типа Прод.",
                    DataPropertyName = "ProductTypeID",
                    Width = 95 // Измененная ширина
                });

                dataGridViewMaterials.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name = "UnitPrice",
                    HeaderText = "Цена",
                    DataPropertyName = "UnitPrice",
                    Width = 90
                });

                dataGridViewMaterials.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name = "StockQuantity",
                    HeaderText = "На Складе",
                    DataPropertyName = "StockQuantity",
                    Width = 90
                });

                dataGridViewMaterials.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name = "MinimumQuantity",
                    HeaderText = "Мин. Кол-во",
                    DataPropertyName = "MinimumQuantity",
                    Width = 90
                });

                dataGridViewMaterials.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name = "PackageQuantity",
                    HeaderText = "В Упак.",
                    DataPropertyName = "PackageQuantity",
                    Width = 80
                });

                dataGridViewMaterials.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name = "UnitOfMeasure",
                    HeaderText = "Ед. Изм.",
                    DataPropertyName = "UnitOfMeasure",
                    Width = 60
                });

                dataGridViewMaterials.DataSource = materials;

                // Обновление заголовка с количеством записей
                this.Text = $"Система управления материалами - Комфорт ({materials.Count} материалов)";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}",
                              "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Обработчик нажатия кнопки "Добавить материал"
        /// </summary>
        private void ButtonAdd_Click(object sender, EventArgs e)
        {
            try
            {
                using (var form = new MaterialEditForm())
                {
                    if (form.ShowDialog() == DialogResult.OK)
                    {
                        LoadMaterials(); // Перезагрузка списка материалов после добавления
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении материала: {ex.Message}",
                              "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Обработчик нажатия кнопки "Удалить материал"
        /// </summary>
        private void ButtonDelete_Click(object sender, EventArgs e)
        {
            if (dataGridViewMaterials.SelectedRows.Count > 0)
            {
                try
                {
                    var selectedMaterials = dataGridViewMaterials.SelectedRows.Cast<DataGridViewRow>()
                        .Select(row => materials[row.Index])
                        .ToList();

                    if (MessageBox.Show("Вы уверены, что хотите удалить выбранные материалы?",
                                      "Подтверждение удаления", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        foreach (var material in selectedMaterials)
                        {
                            databaseHelper.DeleteMaterial(material.MaterialID);
                        }
                        LoadMaterials(); // Перезагрузка списка материалов после удаления
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при удалении материалов: {ex.Message}",
                                  "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        /// <summary>
        /// Обработчик двойного клика по строке в DataGridView для редактирования
        /// </summary>
        private void DataGridViewMaterials_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < materials.Count)
            {
                try
                {
                    var selectedMaterial = materials[e.RowIndex];
                    if (selectedMaterial == null)
                    {
                        MessageBox.Show("Выбранный материал не найден или поврежден. Пожалуйста, обновите список.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    EditMaterial(selectedMaterial); // Открываем форму редактирования напрямую
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при редактировании материала: {ex.Message}",
                                  "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        /// <summary>
        /// Редактирование материала
        /// </summary>
        private void EditMaterial(Material material)
        {
            try
            {
                using (var form = new MaterialEditForm(material))
                {
                    if (form.ShowDialog() == DialogResult.OK)
                    {
                        LoadMaterials(); // Перезагрузка списка материалов после редактирования
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при редактировании материала: {ex.Message}",
                              "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Просмотр поставщиков для выбранного материала
        /// </summary>
        private void ShowSuppliers(Material material)
        {
            try
            {
                using (var form = new SupplierListForm(material))
                {
                    form.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при просмотре поставщиков: {ex.Message}",
                              "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Обработчик нажатия кнопки "Просмотр поставщиков"
        /// </summary>
        private void ButtonViewSuppliers_Click(object sender, EventArgs e)
        {
            if (dataGridViewMaterials.SelectedRows.Count > 0)
            {
                try
                {
                    var selectedMaterial = materials[dataGridViewMaterials.SelectedRows[0].Index];
                    // Проверяем, есть ли поставщики для данного материала
                    var suppliersForMaterial = databaseHelper.GetAllMaterialSuppliersByMaterialId(selectedMaterial.MaterialID);
                    if (suppliersForMaterial != null && suppliersForMaterial.Any())
                    {
                        ShowSuppliers(selectedMaterial);
                    }
                    else
                    {
                        MessageBox.Show("Для выбранного материала поставщики не найдены.", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при просмотре поставщиков: {ex.Message}",
                                  "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        /// <summary>
        /// Обработчик изменения выделения в DataGridView
        /// </summary>
        private void DataGridViewMaterials_SelectionChanged(object sender, EventArgs e)
        {
            // Включаем или отключаем кнопку "Просмотр поставщиков" в зависимости от наличия выбранной строки
            buttonViewSuppliers.Enabled = dataGridViewMaterials.SelectedRows.Count > 0;
        }

        private void LoadMaterialTypeFilters()
        {
            try
            {
                var materialTypes = databaseHelper.GetMaterialTypes();
                materialTypes.Insert(0, new MaterialType { MaterialTypeID = -1, MaterialTypeName = "Все типы материала" }); // Опция "Все"
                cmbMaterialTypeFilter.DisplayMember = "MaterialTypeName";
                cmbMaterialTypeFilter.ValueMember = "MaterialTypeID";
                cmbMaterialTypeFilter.DataSource = materialTypes;
                cmbMaterialTypeFilter.SelectedValue = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке фильтров типов материала: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadProductTypeFilters()
        {
            try
            {
                var productTypes = databaseHelper.GetProductTypes();
                productTypes.Insert(0, new ProductType { ProductTypeId = -1, ProductTypeName = "Все типы продукции" }); // Опция "Все"
                cmbProductTypeFilter.DisplayMember = "ProductTypeName";
                cmbProductTypeFilter.ValueMember = "ProductTypeId";
                cmbProductTypeFilter.DataSource = productTypes;
                cmbProductTypeFilter.SelectedValue = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке фильтров типов продукции: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            LoadMaterials();
        }
    }
} 