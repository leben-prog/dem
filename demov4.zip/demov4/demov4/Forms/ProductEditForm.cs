using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;
using demov4.Data;
using demov4.Models;

namespace demov4.Forms
{
    /// <summary>
    /// Форма для добавления и редактирования продукции
    /// </summary>
    public partial class ProductEditForm : Form
    {
        private DatabaseHelper databaseHelper;
        private Product currentProduct;
        private bool isEditMode;

        // Элементы управления
        private TextBox textBoxArticle;
        private ComboBox comboBoxProductType;
        private TextBox textBoxProductName;
        private TextBox textBoxMinCost;
        private TextBox textBoxMainMaterial;
        private Button buttonSave;
        private Button buttonCancel;

        public ProductEditForm(int? productId = null)
        {
            InitializeComponent();
            databaseHelper = new DatabaseHelper();
            isEditMode = productId.HasValue;
            
            InitializeCustomComponents();
            LoadProductTypes();
            
            if (isEditMode)
            {
                LoadProduct(productId.Value);
            }
        }

        /// <summary>
        /// Инициализация пользовательских компонентов
        /// </summary>
        private void InitializeCustomComponents()
        {
            // Настройка формы
            this.Text = isEditMode ? "Редактирование продукта" : "Добавление продукта";
            this.Size = new Size(500, 400);
            this.StartPosition = FormStartPosition.CenterParent;
            this.BackColor = Color.White;
            this.Font = new Font("Candara", 10F);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            int yPosition = 30;
            int labelWidth = 150;
            int controlWidth = 300;
            int spacing = 40;

            // Артикул
            var labelArticle = new Label
            {
                Text = "Артикул:",
                Location = new Point(20, yPosition),
                Size = new Size(labelWidth, 25),
                Font = new Font("Candara", 10F)
            };

            textBoxArticle = new TextBox
            {
                Location = new Point(180, yPosition),
                Size = new Size(controlWidth, 25),
                Font = new Font("Candara", 10F)
            };

            yPosition += spacing;

            // Тип продукции
            var labelProductType = new Label
            {
                Text = "Тип продукции:",
                Location = new Point(20, yPosition),
                Size = new Size(labelWidth, 25),
                Font = new Font("Candara", 10F)
            };

            comboBoxProductType = new ComboBox
            {
                Location = new Point(180, yPosition),
                Size = new Size(controlWidth, 25),
                Font = new Font("Candara", 10F),
                DropDownStyle = ComboBoxStyle.DropDownList
            };

            yPosition += spacing;

            // Наименование
            var labelProductName = new Label
            {
                Text = "Наименование:",
                Location = new Point(20, yPosition),
                Size = new Size(labelWidth, 25),
                Font = new Font("Candara", 10F)
            };

            textBoxProductName = new TextBox
            {
                Location = new Point(180, yPosition),
                Size = new Size(controlWidth, 25),
                Font = new Font("Candara", 10F)
            };

            yPosition += spacing;

            // Минимальная стоимость
            var labelMinCost = new Label
            {
                Text = "Мин. стоимость:",
                Location = new Point(20, yPosition),
                Size = new Size(labelWidth, 25),
                Font = new Font("Candara", 10F)
            };

            textBoxMinCost = new TextBox
            {
                Location = new Point(180, yPosition),
                Size = new Size(controlWidth, 25),
                Font = new Font("Candara", 10F)
            };

            yPosition += spacing;

            // Основной материал
            var labelMainMaterial = new Label
            {
                Text = "Основной материал:",
                Location = new Point(20, yPosition),
                Size = new Size(labelWidth, 25),
                Font = new Font("Candara", 10F)
            };

            textBoxMainMaterial = new TextBox
            {
                Location = new Point(180, yPosition),
                Size = new Size(controlWidth, 25),
                Font = new Font("Candara", 10F)
            };

            yPosition += spacing + 20;

            // Кнопки
            buttonSave = new Button
            {
                Text = isEditMode ? "Сохранить" : "Добавить",
                Location = new Point(180, yPosition),
                Size = new Size(100, 35),
                BackColor = ColorTranslator.FromHtml("#355CBD"),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Candara", 10F),
                Cursor = Cursors.Hand
            };
            buttonSave.FlatAppearance.BorderSize = 0;
            buttonSave.Click += ButtonSave_Click;

            buttonCancel = new Button
            {
                Text = "Отмена",
                Location = new Point(300, yPosition),
                Size = new Size(100, 35),
                BackColor = ColorTranslator.FromHtml("#D2DFFF"),
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Candara", 10F),
                Cursor = Cursors.Hand
            };
            buttonCancel.FlatAppearance.BorderSize = 0;
            buttonCancel.Click += ButtonCancel_Click;

            // Добавление элементов на форму
            this.Controls.Add(labelArticle);
            this.Controls.Add(textBoxArticle);
            this.Controls.Add(labelProductType);
            this.Controls.Add(comboBoxProductType);
            this.Controls.Add(labelProductName);
            this.Controls.Add(textBoxProductName);
            this.Controls.Add(labelMinCost);
            this.Controls.Add(textBoxMinCost);
            this.Controls.Add(labelMainMaterial);
            this.Controls.Add(textBoxMainMaterial);
            this.Controls.Add(buttonSave);
            this.Controls.Add(buttonCancel);

            // Настройка валидации для поля стоимости
            textBoxMinCost.KeyPress += TextBoxMinCost_KeyPress;
        }

        /// <summary>
        /// Загрузка типов продукции в ComboBox
        /// </summary>
        private void LoadProductTypes()
        {
            try
            {
                var productTypes = databaseHelper.GetProductTypes();
                comboBoxProductType.DataSource = productTypes;
                comboBoxProductType.DisplayMember = "TypeName";
                comboBoxProductType.ValueMember = "ProductTypeId";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке типов продукции: {ex.Message}", 
                              "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Загрузка данных продукта для редактирования
        /// </summary>
        private void LoadProduct(int productId)
        {
            try
            {
                currentProduct = databaseHelper.GetProductById(productId);
                if (currentProduct != null)
                {
                    textBoxArticle.Text = currentProduct.Article;
                    comboBoxProductType.SelectedValue = currentProduct.ProductTypeId;
                    textBoxProductName.Text = currentProduct.ProductName;
                    textBoxMinCost.Text = currentProduct.MinCostForPartner.ToString("F2", CultureInfo.InvariantCulture);
                    textBoxMainMaterial.Text = currentProduct.MainMaterial;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных продукта: {ex.Message}", 
                              "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Валидация ввода только цифр и точки для поля стоимости
        /// </summary>
        private void TextBoxMinCost_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Разрешаем цифры, точку, запятую, backspace и delete
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && 
                e.KeyChar != '.' && e.KeyChar != ',')
            {
                e.Handled = true;
            }

            // Разрешаем только одну точку или запятую
            if ((e.KeyChar == '.' || e.KeyChar == ',') && 
                (textBoxMinCost.Text.Contains('.') || textBoxMinCost.Text.Contains(',')))
            {
                e.Handled = true;
            }
        }

        /// <summary>
        /// Валидация введенных данных
        /// </summary>
        private bool ValidateInput()
        {
            // Проверка артикула
            if (string.IsNullOrWhiteSpace(textBoxArticle.Text))
            {
                MessageBox.Show("Поле 'Артикул' обязательно для заполнения.", 
                              "Ошибка валидации", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBoxArticle.Focus();
                return false;
            }

            // Проверка типа продукции
            if (comboBoxProductType.SelectedValue == null)
            {
                MessageBox.Show("Необходимо выбрать тип продукции.", 
                              "Ошибка валидации", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                comboBoxProductType.Focus();
                return false;
            }

            // Проверка наименования
            if (string.IsNullOrWhiteSpace(textBoxProductName.Text))
            {
                MessageBox.Show("Поле 'Наименование' обязательно для заполнения.", 
                              "Ошибка валидации", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBoxProductName.Focus();
                return false;
            }

            // Проверка стоимости
            string costText = textBoxMinCost.Text.Replace(',', '.');
            if (!decimal.TryParse(costText, NumberStyles.Number, CultureInfo.InvariantCulture, out decimal cost) || cost < 0)
            {
                MessageBox.Show("Введите корректную стоимость (неотрицательное число).", 
                              "Ошибка валидации", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBoxMinCost.Focus();
                return false;
            }

            // Проверка основного материала
            if (string.IsNullOrWhiteSpace(textBoxMainMaterial.Text))
            {
                MessageBox.Show("Поле 'Основной материал' обязательно для заполнения.", 
                              "Ошибка валидации", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBoxMainMaterial.Focus();
                return false;
            }

            return true;
        }

        /// <summary>
        /// Обработчик нажатия кнопки "Сохранить/Добавить"
        /// </summary>
        private void ButtonSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (!ValidateInput())
                    return;

                string costText = textBoxMinCost.Text.Replace(',', '.');
                decimal cost = decimal.Parse(costText, NumberStyles.Number, CultureInfo.InvariantCulture);

                var product = new Product
                {
                    Article = textBoxArticle.Text.Trim(),
                    ProductTypeId = (int)comboBoxProductType.SelectedValue,
                    ProductName = textBoxProductName.Text.Trim(),
                    MinCostForPartner = cost,
                    MainMaterial = textBoxMainMaterial.Text.Trim()
                };

                if (isEditMode)
                {
                    product.ProductId = currentProduct.ProductId;
                    databaseHelper.UpdateProduct(product);
                }
                else
                {
                    databaseHelper.AddProduct(product);
                }

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении продукта: {ex.Message}", 
                              "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Обработчик нажатия кнопки "Отмена"
        /// </summary>
        private void ButtonCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        /// <summary>
        /// Обработчик события загрузки формы
        /// </summary>
        private void ProductEditForm_Load(object sender, EventArgs e)
        {
            // Дополнительная инициализация при необходимости
        }
    }
} 