using System;
using System.Windows.Forms;
using demov4.Models;
using demov4.Data;

namespace demov4.Forms
{
    public partial class MaterialEditForm : Form
    {
        private readonly DatabaseHelper _db;
        private readonly Material _material;
        private readonly bool _isEditMode;

        public MaterialEditForm(Material material = null)
        {
            InitializeComponent();
            _db = new DatabaseHelper();
            _material = material ?? new Material();
            _isEditMode = material != null;
            InitializeForm();
        }

        private void InitializeComponent()
        {
            this.Text = _isEditMode ? "Редактирование материала" : "Добавление материала";
            this.Size = new System.Drawing.Size(400, 560);
            this.MinimumSize = new System.Drawing.Size(300, 300);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = System.Drawing.Color.White;
            this.Font = new System.Drawing.Font("Comic Sans MS", 10F);

            // Создание и настройка элементов управления
            var lblName = new Label { Text = "Наименование:", Location = new System.Drawing.Point(20, 20), Font = new System.Drawing.Font("Comic Sans MS", 10F) };
            var txtName = new TextBox { Location = new System.Drawing.Point(20, 45), Width = 340, Font = new System.Drawing.Font("Comic Sans MS", 10F) };

            var lblType = new Label { Text = "Тип материала:", Location = new System.Drawing.Point(20, 85), Font = new System.Drawing.Font("Comic Sans MS", 10F) };
            var cmbType = new ComboBox { Location = new System.Drawing.Point(20, 110), Width = 340, DropDownStyle = ComboBoxStyle.DropDownList, Font = new System.Drawing.Font("Comic Sans MS", 10F), BackColor = System.Drawing.ColorTranslator.FromHtml("#ABCFCE") };

            var lblStock = new Label { Text = "Количество на складе:", Location = new System.Drawing.Point(20, 150), Font = new System.Drawing.Font("Comic Sans MS", 10F) };
            var numStock = new NumericUpDown { Location = new System.Drawing.Point(20, 175), Width = 340, DecimalPlaces = 2, Minimum = 0, Maximum = 999999999M, Font = new System.Drawing.Font("Comic Sans MS", 10F), BackColor = System.Drawing.ColorTranslator.FromHtml("#ABCFCE") };

            var lblUnit = new Label { Text = "Единица измерения:", Location = new System.Drawing.Point(20, 215), Font = new System.Drawing.Font("Comic Sans MS", 10F) };
            var txtUnit = new TextBox { Location = new System.Drawing.Point(20, 240), Width = 340, Font = new System.Drawing.Font("Comic Sans MS", 10F) };

            var lblPackage = new Label { Text = "Количество в упаковке:", Location = new System.Drawing.Point(20, 280), Font = new System.Drawing.Font("Comic Sans MS", 10F) };
            var numPackage = new NumericUpDown { Location = new System.Drawing.Point(20, 305), Width = 340, Minimum = 1, DecimalPlaces = 0, Maximum = 999999999, Font = new System.Drawing.Font("Comic Sans MS", 10F), BackColor = System.Drawing.ColorTranslator.FromHtml("#ABCFCE") };

            var lblMin = new Label { Text = "Минимальное количество:", Location = new System.Drawing.Point(20, 345), Font = new System.Drawing.Font("Comic Sans MS", 10F) };
            var numMin = new NumericUpDown { Location = new System.Drawing.Point(20, 370), Width = 340, Minimum = 0, DecimalPlaces = 2, Maximum = 999999999M, Font = new System.Drawing.Font("Comic Sans MS", 10F), BackColor = System.Drawing.ColorTranslator.FromHtml("#ABCFCE") };

            var lblPrice = new Label { Text = "Цена единицы:", Location = new System.Drawing.Point(20, 410), Font = new System.Drawing.Font("Comic Sans MS", 10F) };
            var numPrice = new NumericUpDown { Location = new System.Drawing.Point(20, 435), Width = 340, DecimalPlaces = 2, Minimum = 0, Maximum = 999999999M, Font = new System.Drawing.Font("Comic Sans MS", 10F), BackColor = System.Drawing.ColorTranslator.FromHtml("#ABCFCE") };

            var btnSave = new Button
            {
                Text = "Сохранить",
                Location = new System.Drawing.Point(20, 480),
                Width = 160,
                Font = new System.Drawing.Font("Comic Sans MS", 10F),
                BackColor = System.Drawing.ColorTranslator.FromHtml("#546F94"),
                ForeColor = System.Drawing.Color.White,
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            btnSave.FlatAppearance.BorderSize = 0;

            var btnCancel = new Button
            {
                Text = "Отмена",
                Location = new System.Drawing.Point(200, 480),
                Width = 160,
                Font = new System.Drawing.Font("Comic Sans MS", 10F),
                BackColor = System.Drawing.ColorTranslator.FromHtml("#546F94"),
                ForeColor = System.Drawing.Color.White,
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            btnCancel.FlatAppearance.BorderSize = 0;

            // Добавление элементов на форму
            this.Controls.AddRange(new Control[] {
                lblName, txtName,
                lblType, cmbType,
                lblStock, numStock,
                lblUnit, txtUnit,
                lblPackage, numPackage,
                lblMin, numMin,
                lblPrice, numPrice,
                btnSave, btnCancel
            });

            // Обработчики событий
            btnSave.Click += (s, e) => SaveMaterial(txtName, cmbType, numStock, txtUnit, numPackage, numMin, numPrice);
            btnCancel.Click += (s, e) => this.Close();

            // Сохранение ссылок на элементы управления
            this.txtName = txtName;
            this.cmbType = cmbType;
            this.numStock = numStock;
            this.txtUnit = txtUnit;
            this.numPackage = numPackage;
            this.numMin = numMin;
            this.numPrice = numPrice;
        }

        private TextBox txtName;
        private ComboBox cmbType;
        private NumericUpDown numStock;
        private TextBox txtUnit;
        private NumericUpDown numPackage;
        private NumericUpDown numMin;
        private NumericUpDown numPrice;

        private void InitializeForm()
        {
            try
            {
                // Загрузка типов материалов
                var materialTypes = _db.GetMaterialTypes();
                cmbType.DisplayMember = "MaterialTypeName";
                cmbType.ValueMember = "MaterialTypeID";
                cmbType.DataSource = materialTypes;

                if (_isEditMode)
                {
                    // Заполнение полей данными материала
                    txtName.Text = _material.MaterialName;
                    cmbType.SelectedValue = _material.MaterialTypeID;
                    numStock.Value = (decimal)_material.StockQuantity;
                    txtUnit.Text = _material.UnitOfMeasure;
                    numPackage.Value = _material.PackageQuantity;
                    numMin.Value = (decimal)_material.MinimumQuantity;
                    numPrice.Value = _material.UnitPrice;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при инициализации формы: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.DialogResult = DialogResult.Cancel;
                this.Close();
            }
        }

        private void SaveMaterial(TextBox txtName, ComboBox cmbType, NumericUpDown numStock, 
            TextBox txtUnit, NumericUpDown numPackage, NumericUpDown numMin, NumericUpDown numPrice)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtName.Text))
                {
                    MessageBox.Show("Введите наименование материала", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (cmbType.SelectedValue == null)
                {
                    MessageBox.Show("Выберите тип материала", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtUnit.Text))
                {
                    MessageBox.Show("Введите единицу измерения", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Обновление данных материала
                _material.MaterialName = txtName.Text;
                _material.MaterialTypeID = (int)cmbType.SelectedValue;
                _material.StockQuantity = (decimal)numStock.Value;
                _material.UnitOfMeasure = txtUnit.Text;
                _material.PackageQuantity = (int)numPackage.Value;
                _material.MinimumQuantity = (decimal)numMin.Value;
                _material.UnitPrice = numPrice.Value;

                // Сохранение в базу данных
                if (_isEditMode)
                {
                    _db.UpdateMaterial(_material);
                }
                else
                {
                    _db.AddMaterial(_material);
                }

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении материала: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
} 