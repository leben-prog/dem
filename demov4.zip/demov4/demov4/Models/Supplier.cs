using System;

namespace demov4.Models
{
    public class Supplier
    {
        public int SupplierID { get; set; }
        public string SupplierName { get; set; }
        public string SupplierType { get; set; }
        public string INN { get; set; }
        public int Rating { get; set; }
        public DateTime StartDate { get; set; }
    }
} 