namespace demov4.Models
{
    public class Material
    {
        public int MaterialID { get; set; }
        public string MaterialName { get; set; }
        public int MaterialTypeID { get; set; }
        public int ProductTypeID { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal StockQuantity { get; set; }
        public decimal MinimumQuantity { get; set; }
        public int PackageQuantity { get; set; }
        public string UnitOfMeasure { get; set; }
    }
} 