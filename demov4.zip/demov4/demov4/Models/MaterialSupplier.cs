using System;

namespace demov4.Models
{
    public class MaterialSupplier
    {
        public int MaterialSupplierID { get; set; }
        public int MaterialID { get; set; }
        public int SupplierID { get; set; }
        public Supplier Supplier { get; set; }
    }
} 