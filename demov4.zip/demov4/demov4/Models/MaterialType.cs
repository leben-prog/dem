namespace demov4.Models
{
    /// <summary>
    /// Модель типа материала
    /// </summary>
    public class MaterialType
    {
        public int MaterialTypeID { get; set; }
        public string MaterialTypeName { get; set; }
        public decimal RawMaterialLossPercent { get; set; }
    }
} 