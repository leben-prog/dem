﻿using System;
using System.Windows.Forms;
using demov4.Forms;

namespace demov4
{
    /// <summary>
    /// Главный класс приложения
    /// </summary>
    internal static class Program
    {
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            
            // Запуск главной формы приложения
            Application.Run(new MainForm());
        }
    }
}
